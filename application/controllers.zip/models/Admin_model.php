<?php

class Admin_model extends CI_Model
{
	function __construct()
	{
		$this->detailsTable = 'details';
	}

	function totalUser()
	{
		$this->db->select('*');
		$this->db->from(TABLE_USERS);
		$this->db->where('type !=', 'Admin');
		$this->db->where('deleted', 0);
		return $this->db->get()->num_rows();
	}

	function totalCompleteProduction()
	{
		$this->db->select('*');
		$this->db->from(TABLE_PRODUCTIONS);
		$this->db->where('completedStatus', 'Complete');
		return $this->db->get()->num_rows();
	}

	function totalIncompleteProduction()
	{
		$this->db->select('*');
		$this->db->from(TABLE_PRODUCTIONS);
		$this->db->where('completedStatus', 'In-progress');
		return $this->db->get()->num_rows();
	}

	function getCustomers()
	{
		$this->db->select('*');
		$this->db->from(TABLE_USERS);
		$this->db->where(array('id !=' => getSession()->id));
		return $this->db->get();
	}

	function getCustomerSearch($searchTerm = "")
	{
		$this->db->select('*, name as text');
		$this->db->from(TABLE_USERS);
		$this->db->where("name like '%" . $searchTerm . "%'");
		$value = $this->db->get()->result();
		$data = array();
		foreach ($value as $val) {
			if ($val->deleted == 0 && $val->type != 'Admin') {
				$data[] = $val;
			}
		}
		return $data;
	}

	function fetch_email($email)
	{
		$this->db->select('username');
		// $this->db->where("username like '%" . $email . "%'");
		$this->db->where(array('username' => $email, 'deleted' => 0));
		$query = $this->db->get(TABLE_USERS);
		if ($query->num_rows() > 0) {
			return true;
		} else {
			return false;
		}
	}

	function saveCustomer($arr)
	{
		$this->db->insert(TABLE_USERS, $arr);
	}

	function getCustomerById($id)
	{
		$this->db->select('*');
		$this->db->from(TABLE_USERS);
		$this->db->where('id', $id);
		return $this->db->get()->row();
	}

	function updateCustomer($arr, $id)
	{
		$this->db->update(TABLE_USERS, $arr, array('id' => $id));
	}

	function deleteCustomer($id)
	{
		$this->db->where('id', $id);
		$this->db->delete(TABLE_USERS);
	}

	// production
	function save($arr)
	{
		$this->db->insert(TABLE_PRODUCTIONS, $arr);
	}

	function update($arr, $id)
	{
		$this->db->update(TABLE_PRODUCTIONS, $arr, array('id' => $id));
	}

	function getProductionById($id)
	{
		$this->db->select('*');
		$this->db->from(TABLE_PRODUCTIONS);
		$this->db->where('id', $id);
		return $this->db->get()->row();
	}


	// Production
	function getLastProductionID()
	{
		$this->db->select('id, status');
		$this->db->from(TABLE_PRODUCTIONS);
		$this->db->order_by('id', 'desc');
		return $this->db->get()->row();
	}

	function getLastProductionIDByUser()
	{
		$this->db->select('id, status');
		$this->db->from(TABLE_PRODUCTIONS);
		$this->db->where('addedBy', getSession()->id);
		$this->db->order_by('id', 'desc');
		return $this->db->get()->row();
	}

	function deleteProduction($id)
	{
		$this->db->where('id', $id);
		$this->db->delete(TABLE_PRODUCTIONS);
	}

	//Crew Member
	function saveCrewMember($arr)
	{
		$this->db->insert(TABLE_CREWMEMBERS, $arr);
	}

	function getCrewMemberByProductionId($id)
	{
		$this->db->select('*');
		$this->db->from(TABLE_CREWMEMBERS);
		$this->db->where('productionId', $id);
		$this->db->order_by('id', 'asc');
		return $this->db->get()->result();
	}

	function getCrewMemberById($id)
	{
		$this->db->select('*');
		$this->db->from(TABLE_CREWMEMBERS);
		$this->db->where('id', $id);
		return $this->db->get()->row();
	}

	function updateCrewMember($arr, $id)
	{
		$this->db->update(TABLE_CREWMEMBERS, $arr, array('id' => $id));
	}

	function deleteCrewMember($id)
	{
		$this->db->where('id', $id);
		$this->db->delete(TABLE_CREWMEMBERS);
	}

	//Theatre Crew Member
	function saveTheatreCrew($arr)
	{
		$this->db->insert(TABLE_THEATRECREW, $arr);
	}

	function getTheatreCrewByProductionId($id)
	{
		$this->db->select('*');
		$this->db->from(TABLE_THEATRECREW);
		$this->db->where('productionId', $id);
		$this->db->order_by('id', 'asc');
		return $this->db->get()->result();
	}

	function getTheatreCrewById($id)
	{
		$this->db->select('*');
		$this->db->from(TABLE_THEATRECREW);
		$this->db->where('id', $id);
		return $this->db->get()->row();
	}

	function updateTheatreCrew($arr, $id)
	{
		$this->db->update(TABLE_THEATRECREW, $arr, array('id' => $id));
	}

	function deleteTheatreCrew($id)
	{
		$this->db->where('id', $id);
		$this->db->delete(TABLE_THEATRECREW);
	}

	// Entertainer
	function saveEntertainer($arr)
	{
		$this->db->insert(TABLE_ENTERTAINER, $arr);
	}

	function getEntertainerByProductionId($id)
	{
		$this->db->select('*');
		$this->db->from(TABLE_ENTERTAINER);
		$this->db->where('productionId', $id);
		$this->db->order_by('id', 'asc');
		return $this->db->get()->result();
	}

	function getEntertainerById($id)
	{
		$this->db->select('*');
		$this->db->from(TABLE_ENTERTAINER);
		$this->db->where('id', $id);
		return $this->db->get()->row();
	}

	function updateEntertainer($arr, $id)
	{
		$this->db->update(TABLE_ENTERTAINER, $arr, array('id' => $id));
	}

	function deleteEntertainer($id)
	{
		$this->db->where('id', $id);
		$this->db->delete(TABLE_ENTERTAINER);
	}

	//Marketing Fee
	function saveMarketingFee($arr)
	{
		$this->db->insert(TABLE_MARKETINGFEE, $arr);
	}

	function getMarketingFeeByProductionId($id)
	{
		$this->db->select('*');
		$this->db->from(TABLE_MARKETINGFEE);
		$this->db->where('productionId', $id);
		$this->db->order_by('id', 'asc');
		return $this->db->get()->result();
	}

	function getMarketingFeeById($id)
	{
		$this->db->select('*');
		$this->db->from(TABLE_MARKETINGFEE);
		$this->db->where('id', $id);
		return $this->db->get()->row();
	}

	function updateMarketingFee($arr, $id)
	{
		$this->db->update(TABLE_MARKETINGFEE, $arr, array('id' => $id));
	}

	function deleteMarketingFee($id)
	{
		$this->db->where('id', $id);
		$this->db->delete(TABLE_MARKETINGFEE);
	}


	//Rentals & Misc Fee
	function saveRentalAndMisc($arr)
	{
		$this->db->insert(TABLE_RENTALANDMISC, $arr);
	}

	function getRentalAndMiscByProductionId($id)
	{
		$this->db->select('*');
		$this->db->from(TABLE_RENTALANDMISC);
		$this->db->where('productionId', $id);
		$this->db->order_by('id', 'asc');
		return $this->db->get()->result();
	}

	function getRentalAndMiscById($id)
	{
		$this->db->select('*');
		$this->db->from(TABLE_RENTALANDMISC);
		$this->db->where('id', $id);
		return $this->db->get()->row();
	}

	function updateRentalAndMisc($arr, $id)
	{
		$this->db->update(TABLE_RENTALANDMISC, $arr, array('id' => $id));
	}

	function deleteRentalAndMisc($id)
	{
		$this->db->where('id', $id);
		$this->db->delete(TABLE_RENTALANDMISC);
	}

}
