<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-body" style="background: black">
				<div class="row">
					<div class="col-md-12 text-center">
						<img class="responsive-img" src="<?= base_url('images/3.png') ?>" alt="User Image">
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-6">
		<div class="box box-success">
			<div class="box-body">
				<div class="row">
					<div class="col-md-6">
						<a href="<?= customer_url('productions') ?>">
							<div class="small-box bg-black-gradient">
								<div class="inner">
									<h3><?= $totalCompleteProduction ?></h3>
									<p>Total Completed Productions</p>
								</div>
								<div class="icon">
									<i class="fa fa-tasks"></i>
								</div>
							</div>
						</a>
					</div>
					<div class="col-md-6">
						<div class="small-box bg-blue-gradient">
							<div class="inner">
								<h3><?= $totalIncompleteProduction ?></h3>
								<p>Total In-Progress Productions</p>
							</div>
							<div class="icon">
								<i class="fa fa-tasks"></i>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="box box-info">
			<div class="box-header">
				<h3 class="box-title">Complete vs In-progress Chart</h3>
			</div>
			<div class="box-body">
				<div class="chartSpace">
					<canvas id="chartContainer" style="height: 400px; width: 100%;"></canvas>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	$(function () {
		var cData = JSON.parse(`<?php echo $data1; ?>`);
		var ctx = document.getElementById("chartContainer");
		var options = {
			scales: {
				xAxes: [{
					barPercentage: 1.0
				}],
				yAxes: [{
					ticks: {
						beginAtZero: true,
						aspectRatio: false
					}
				}]
			},
			gridLines: {
				display: true
			},
			responsive: true,
			title: {
				display: false,
			},
			legend: {
				display: false,
			},
			plugins: {
				colorschemes: {
					scheme: 'brewer.Paired12'
				}
			}
		};
		var dataPie = {
			labels: ['Complete', 'In-progress'],
			datasets: [
				{
					label: 'Total',
					data: [cData.totalComplete, cData.totalIncomplete],
					backgroundColor: [
						'#212121',
						'#0081CE',
					],
					hoverBackgroundColor: [
						'#3D3D3D',
						'#0099E5',
					],
					hoverOffset: 4
				}
			]
		}
		var chart2 = new Chart(ctx, {
			type: "pie",
			data: dataPie,
			options: {
				responsive: true,
				title: {
					display: false,
				}
			}
		});
	});
</script>
