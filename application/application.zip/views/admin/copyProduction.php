<div class="modal fade in" id="modal-default" style="display: block;overflow: auto;">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="btn btn-danger pull-right" data-dismiss="modal" aria-label="Close">Close
				</button>
				<h4 class="modal-title"><b>Copy Production</b></h4>
			</div>
			<form role="form" action="<?= admin_url('saveCopyProduction/' . $data->id) ?>" method="post">
				<div class="modal-body">
					<div class="row">
						<div class="form-group col-md-12">
							<label for="title">PRODUCTION TITLE <span class="text-danger">*</span></label>
							<input class="form-control input-sm" type="text" name="title" id="title" required
								   placeholder="Enter production title">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-4">
							<label for="eventMonth">EVENT MONTH <span class="text-danger">*</span></label>
							<select class="form-control input-sm" name="eventMonth" id="eventMonth" required>
								<option <?= (date('F') == 'January') ? 'selected' : '' ?>
										value="January">January
								</option>
								<option <?= (date('F') == 'February') ? 'selected' : '' ?>
										value="February">February
								</option>
								<option <?= (date('F') == 'March') ? 'selected' : '' ?>
										value="March">March
								</option>
								<option <?= (date('F') == 'April') ? 'selected' : '' ?>
										value="April">April
								</option>
								<option <?= (date('F') == 'May') ? 'selected' : '' ?>
										value="May">May
								</option>
								<option <?= (date('F') == 'June') ? 'selected' : '' ?>
										value="June">June
								</option>
								<option <?= (date('F') == 'July') ? 'selected' : '' ?>
										value="July">July
								</option>
								<option <?= (date('F') == 'August') ? 'selected' : '' ?>
										value="August">August
								</option>
								<option <?= (date('F') == 'September') ? 'selected' : '' ?>
										value="September">September
								</option>
								<option <?= (date('F') == 'October') ? 'selected' : '' ?>
										value="October">October
								</option>
								<option <?= (date('F') == 'November') ? 'selected' : '' ?>
										value="November">November
								</option>
								<option <?= (date('F') == 'December') ? 'selected' : '' ?>
										value="December">December
								</option>
							</select>
						</div>
						<div class="form-group col-md-4">
							<label for="eventYear">EVENT YEAR <span class="text-danger">*</span></label>
							<input class="form-control input-sm" type="number" minlength="4"
								   min="<?= date('Y') ?>"
								   name="eventYear" value="<?= date('Y') ?>"
								   id="eventYear" required>
						</div>
						<div class="form-group col-md-4">
							<label for="addedBy">ASSIGNED TO <span class="text-danger">*</span></label>
							<select style="width: 100%" id="addedBy" name="addedBy"
									class="form-control selectCustomer" required>
							</select>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label class="checkbox-inline"><input type="checkbox" value="checkbox" id="checkbox">Same
									Value</label>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-6">
							<label for="venueName">VENUE NAME <span class="text-danger">*</span></label>
							<input class="form-control input-sm" type="text" name="venueName"
								   id="venueName" required>
							<input type="hidden" id="venueNameVal" value="<?= $data ? $data->venueName : '' ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="address">ADDRESS <span class="text-danger">*</span></label>
							<input class="form-control input-sm" type="text" name="address"
								   id="address" required>
							<input type="hidden" id="addressVal" value="<?= $data ? $data->address : '' ?>">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-6">
							<label for="city">CITY <span class="text-danger">*</span></label>
							<input class="form-control input-sm" type="text" name="city"
								   id="city" value="<?= $data ? $data->city : '' ?>" required>
							<input type="hidden" id="cityVal" value="<?= $data ? $data->city : '' ?>">
						</div>
						<div class="form-group col-md-6">
							<label for="state">STATE <span class="text-danger">*</span></label>
							<select class="form-control input-sm" name="state" style="width: 100%"
									id="state" required>
								<option value="">Select State</option>
								<!-- Default placeholder option -->
								<?php if ($data) {
									// List of all states
									$states = [
											"Alabama - AL", "Alaska - AK", "Arizona - AZ", "Arkansas - AR",
											"California - CA", "Colorado - CO", "Connecticut - CT", "Delaware - DE",
											"District of Columbia - DC", "Florida - FL", "Georgia - GA", "Guam - GU",
											"Hawaii - HI", "Idaho - ID", "Illinois - IL", "Indiana - IN",
											"Iowa - IA", "Kansas - KS", "Kentucky - KY", "Louisiana - LA",
											"Maine - ME", "Maryland - MD", "Massachusetts - MA", "Michigan - MI",
											"Minnesota - MN", "Mississippi - MS", "Missouri - MO", "Montana - MT",
											"Nebraska - NE", "Nevada - NV", "New Hampshire - NH", "New Jersey - NJ",
											"New Mexico - NM", "New York - NY", "North Carolina - NC", "North Dakota - ND",
											"Ohio - OH", "Oklahoma - OK", "Oregon - OR", "Pennsylvania - PA", "Puerto Rico - PR",
											"Rhode Island - RI", "South Carolina - SC", "South Dakota - SD", "Tennessee - TN",
											"Texas - TX", "Utah - UT", "Vermont - VT", "Virginia - VA", "Virgin Islands - VI",
											"Washington - WA", "West Virginia - WV", "Wisconsin - WI", "Wyoming - WY"
									];
									foreach ($states as $state) {
										echo "<option value='{$state}'>{$state}</option>";
									}
								}
								?>
							</select>
							<input type="hidden" id="stateVal" value="<?= $data ? $data->state : '' ?>">
						</div>
					</div>
				</div>
				<div class="box-footer">
					<div class="row">
						<div class="form-group col-md-12">
							<button type="submit" style="color: white; background-color: black" class="btn pull-right">
								Copy
							</button>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<script>
	$("#checkbox").on('click', function () {
		if ($('[type="checkbox"]').is(":checked")) {
			var venueName = $('#venueNameVal').val();
			var address = $('#addressVal').val();
			var city = $('#cityVal').val();
			var state = $('#stateVal').val();
			console.log(state);
			$('#venueName').val(venueName);
			$('#address').val(address);
			$('#city').val(city);
			$('#state').val(state).trigger("change");
		} else {
			$('#venueName').val('');
			$('#address').val('');
			$('#city').val('');
			$('#state').val('').trigger("change");
		}
	});
	$("#state").select2({
		dropdownParent: $('#remoteModal1'),
		placeholder: "Select a state",
	});
	$(".selectCustomer").select2({
		dropdownParent: $('#remoteModal1'),
		placeholder: "Select Team Member",
		ajax: {
			url: '<?= admin_url("getCustomerSearch") ?>',
			dataType: 'json',
			type: "POST",
			quietMillis: 50,
			allowClear: true,
			data: function (params) {
				return {
					searchTerm: params.term
				};
			},
			processResults: function (response) {
				return {
					results: response
				};
			}
		}
	});
</script>
