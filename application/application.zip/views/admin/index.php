<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-body" style="background: black">
				<div class="row">
					<div class="col-md-12 text-center">
						<img class="responsive-img" src="<?= base_url('images/3.png') ?>" alt="User Image">
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="box box-success">
			<div class="box-body">
				<div class="row">
					<div class="col-md-4">
						<a href="<?= admin_url('customers') ?>">
							<div class="small-box bg-gray-active">
								<div class="inner">
									<h3><?= $totalUser ?></h3>
									<p>Total Team Members</p>
								</div>
								<div class="icon">
									<i class="fa fa-user-secret"></i>
								</div>
							</div>
						</a>
					</div>
					<div class="col-md-4">
						<a href="<?= admin_url('productions') ?>">
							<div class="small-box bg-black-gradient">
								<div class="inner">
									<h3><?= $totalCompleteProduction ?></h3>
									<p>Total Completed Productions</p>
								</div>
								<div class="icon">
									<i class="fa fa-tasks"></i>
								</div>
							</div>
						</a>
					</div>
					<div class="col-md-4">
						<div class="small-box bg-blue-gradient">
							<div class="inner">
								<h3><?= $totalIncompleteProduction ?></h3>
								<p>Total In-Progress Productions</p>
							</div>
							<div class="icon">
								<i class="fa fa-tasks"></i>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="box box-info">
			<div class="row">
				<div class="col-md-12">
					<div class="chartSpace">
						<canvas id="chartContainer" style="height: 400px; width: 100%;"></canvas>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	$(function () {
		var cData = JSON.parse(`<?php echo $data1; ?>`);
		var ctx = document.getElementById("chartContainer");
		var chart = new Chart(ctx, {
			type: "bar",
			options: {
				responsive: true,
				maintainAspectRatio: false,
				scales: {
					xAxes: [{
						barPercentage: 1.0
					}],
					yAxes: [{
						ticks: {
							beginAtZero: true,
							stepSize: 1,
							callback: function (value) {
								return value
							}
						}
					}]
				},
				gridLines: {
					display: true
				},
				responsive: true,
				legend: {
					display: true,
				},
				title: {
					display: true,
					position: "top",
					text: "Total Production By Team Members",
					fontSize: 18,
					fontColor: "#111"
				},
			},
			data: {
				labels: cData.label,
				datasets: [
					{
						type: "bar",
						backgroundColor: '#212121',
						borderWidth: 1,
						barThickness: 1,
						label: "Complete",
						data: cData.totalComplete
					},
					{
						type: "bar",
						backgroundColor: '#0081CE',
						borderWidth: 1,
						barThickness: 1,
						label: "In-progress",
						data: cData.totalIncomplete
					}
				]
			}
		});
	});
</script>
